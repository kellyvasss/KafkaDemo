package com.kelly.demoTest.view;

import com.kelly.demoTest.data.entity.User;
import com.kelly.demoTest.kafka.JsonKafkaProducer;
import com.kelly.demoTest.kafka.controller.JsonMessageController;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.NumberField;
import com.vaadin.flow.component.textfield.TextArea;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.Route;
import org.springframework.kafka.core.KafkaTemplate;

@Route(value = "new-user")
public class AddUserView extends VerticalLayout {
    JsonMessageController controller;
    JsonKafkaProducer kafkaProducer;
    KafkaTemplate<String, User> kafkaTemplate;
    User user;
    NumberField id;
    TextField firstName;
    TextField lastName;
    Button save;
    public AddUserView(KafkaTemplate<String, User> kafkaTemplate,
                       JsonMessageController controller,
                       JsonKafkaProducer kafkaProducer) {
        id = new NumberField("ID");
        firstName = new TextField("Förnamn");
        lastName = new TextField("Efternamn");
        save = new Button("Spara");
        user = new User();
        this.kafkaTemplate = kafkaTemplate;
        this.controller = controller;
        this.kafkaProducer = kafkaProducer;
        save.addClickListener(e -> saveUser());

        add(
                id,
                firstName,
                lastName,
                save
        );
    }

    private void saveUser() {


        user.setId(id.getValue().longValue());
        user.setFirstName(firstName.getValue());
        user.setLastName(lastName.getValue());
        controller.publish(user);
    }


}
